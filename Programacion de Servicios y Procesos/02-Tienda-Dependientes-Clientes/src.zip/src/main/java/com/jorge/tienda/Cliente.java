// Ya no se usa: la solucion actual esta entera en Main.java (clase Dependiente anidada, igual que CoffeeShop.java). Puedes borrar este fichero desde IntelliJ.
